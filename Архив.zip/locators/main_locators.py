class MainLocators:
    # Main page
    ACTUAL_REGION = 'ru.leroymerlin.mobile:id/tv_region'
    INFO_BUTTON = 'ru.leroymerlin.mobile:id/action_info'
    TITLE_DELIVERY = 'ru.leroymerlin.mobile:id/delivery_txt'
    BACK_BUTTON = 'android.widget.ImageButton'
    REGION_NAME = 'ru.leroymerlin.mobile:id/tv_name'
    MYREGION = 'ru.leroymerlin.mobile:id/tv_near_me'